import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALLOWED_ORIGINS = [
  'https://maidforchico.com',
  'https://www.maidforchico.com',
  'https://chico-maid-shine.lovable.app',
];

function getCorsHeaders(req: Request) {
  const origin = req.headers.get('Origin') || '';
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  };
}

const RECIPIENT_EMAIL = "info@maidforchico.com";
const RATE_LIMIT_WINDOW_MINUTES = 60;
const MAX_REQUESTS_PER_WINDOW = 5;

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: getCorsHeaders(req) });
  }

  try {
    const data = await req.json();
    const { name, email, phone, street, city, zip, serviceType, sqft, bedrooms, bathrooms, frequency, preferredDate, preferredTime, notes, otherService, estimateDate, estimateTime } = data;

    // Validate required fields
    if (!name || !email || !phone || !street || !city || !zip || !serviceType || !frequency || !preferredDate) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    // Server-side format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[\d\s\-\+\(\)\.]{7,20}$/;
    const zipRegex = /^\d{5}(-\d{4})?$/;

    if (!emailRegex.test(email)) {
      return new Response(JSON.stringify({ error: "Invalid email format" }), {
        status: 400, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }
    if (!phoneRegex.test(phone)) {
      return new Response(JSON.stringify({ error: "Invalid phone format" }), {
        status: 400, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }
    if (!zipRegex.test(zip)) {
      return new Response(JSON.stringify({ error: "Invalid zip code format" }), {
        status: 400, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    // Length validation
    if (name.length > 100 || email.length > 255 || phone.length > 20 ||
        street.length > 200 || city.length > 100 || zip.length > 10 ||
        (notes && notes.length > 2000) || (serviceType && serviceType.length > 100) ||
        (otherService && otherService.length > 200)) {
      return new Response(JSON.stringify({ error: "One or more fields exceed maximum length" }), {
        status: 400, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Rate limiting by email
    const rateLimitKey = `booking:${email.toLowerCase().trim()}`;
    const windowStart = new Date(Date.now() - RATE_LIMIT_WINDOW_MINUTES * 60 * 1000).toISOString();

    // Clean old entries and check current count
    await supabaseAdmin.from('rate_limits').delete().lt('window_start', windowStart);

    const { count } = await supabaseAdmin
      .from('rate_limits')
      .select('*', { count: 'exact', head: true })
      .eq('key', rateLimitKey)
      .gte('window_start', windowStart);

    if ((count ?? 0) >= MAX_REQUESTS_PER_WINDOW) {
      return new Response(JSON.stringify({ error: "Too many requests. Please try again later." }), {
        status: 429, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    // Record this request
    await supabaseAdmin.from('rate_limits').insert({ key: rateLimitKey });

    const displayService = serviceType === 'other' && otherService ? `Other: ${otherService}` : serviceType;

    // Escape all user inputs for HTML
    const safeName = escapeHtml(name);
    const safeEmail = escapeHtml(email);
    const safePhone = escapeHtml(phone);
    const safeStreet = escapeHtml(street);
    const safeCity = escapeHtml(city);
    const safeZip = escapeHtml(zip);
    const safeDisplayService = escapeHtml(displayService);
    const safeSqft = sqft ? escapeHtml(sqft) : 'N/A';
    const safeBedrooms = bedrooms ? escapeHtml(bedrooms) : 'N/A';
    const safeBathrooms = bathrooms ? escapeHtml(bathrooms) : 'N/A';
    const safeFrequency = escapeHtml(frequency);
    const safePreferredDate = escapeHtml(preferredDate);
    const safePreferredTime = preferredTime ? escapeHtml(preferredTime) : 'No preference';
    const safeEstimateDate = estimateDate ? escapeHtml(estimateDate) : 'Not specified';
    const safeEstimateTime = estimateTime ? escapeHtml(estimateTime) : 'No preference';
    const safeNotes = notes ? escapeHtml(notes) : '';

    // Store booking in database
    const { error: dbError } = await supabaseAdmin.from('bookings').insert({
      name, email, phone, street, city, zip,
      service_type: displayService,
      sqft: sqft || null,
      bedrooms: bedrooms || null,
      bathrooms: bathrooms || null,
      frequency,
      preferred_date: preferredDate,
      preferred_time: preferredTime || null,
      estimate_date: estimateDate || null,
      estimate_time: estimateTime || null,
      notes: notes || null,
      status: 'pending',
    });

    if (dbError) {
      console.error("Database insert error:", dbError);
    }

    // Send email notification
    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
    
    if (!RESEND_API_KEY) {
      console.error("RESEND_API_KEY not configured");
      return new Response(JSON.stringify({ error: "Email service not configured" }), {
        status: 500,
        headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const emailHtml = `
      <h2>New Cleaning Service Request</h2>
      <hr/>
      <h3>Contact Information</h3>
      <p><strong>Name:</strong> ${safeName}</p>
      <p><strong>Email:</strong> ${safeEmail}</p>
      <p><strong>Phone:</strong> ${safePhone}</p>
      <h3>Service Address</h3>
      <p>${safeStreet}<br/>${safeCity}, CA ${safeZip}</p>
      <h3>In-Home Estimate Visit</h3>
      <p><strong>Requested Date:</strong> ${safeEstimateDate}</p>
      <p><strong>Preferred Time:</strong> ${safeEstimateTime}</p>
      <h3>Service Details</h3>
      <p><strong>Type:</strong> ${safeDisplayService}</p>
      <p><strong>Sq Ft:</strong> ${safeSqft}</p>
      <p><strong>Bedrooms:</strong> ${safeBedrooms}</p>
      <p><strong>Bathrooms:</strong> ${safeBathrooms}</p>
      <p><strong>Frequency:</strong> ${safeFrequency}</p>
      <h3>Desired Cleaning Date</h3>
      <p><strong>Preferred Date:</strong> ${safePreferredDate}</p>
      <p><strong>Preferred Time:</strong> ${safePreferredTime}</p>
      ${safeNotes ? `<h3>Notes</h3><p>${safeNotes}</p>` : ''}
    `;

    const resendRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Maid For Chico <info@maidforchico.com>',
        to: [RECIPIENT_EMAIL],
        subject: `New Cleaning Request from ${safeName}`,
        html: emailHtml,
        reply_to: email,
      }),
    });

    const resendData = await resendRes.json();

    if (!resendRes.ok) {
      console.error("Resend API error:", resendData);
      return new Response(JSON.stringify({ error: "Failed to send email" }), {
        status: 500,
        headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    // Send confirmation email to customer
    const customerEmailHtml = `
      <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        <h1 style="color: #2d2d2d; font-size: 24px; margin-bottom: 8px;">Thank You, ${safeName}!</h1>
        <p style="color: #555; font-size: 16px; line-height: 1.6;">
          We've received your cleaning service request and our team will reach out to you as soon as possible to confirm your appointment.
        </p>
        <div style="background: #f9f9f9; border-left: 4px solid #b8860b; padding: 20px; margin: 24px 0; border-radius: 4px;">
          <h3 style="margin: 0 0 12px; color: #2d2d2d; font-size: 16px;">Your Request Summary</h3>
          <p style="margin: 4px 0; color: #555;"><strong>Service:</strong> ${safeDisplayService}</p>
          <p style="margin: 4px 0; color: #555;"><strong>Frequency:</strong> ${safeFrequency}</p>
          <p style="margin: 4px 0; color: #555;"><strong>Preferred Date:</strong> ${safePreferredDate}</p>
          <p style="margin: 4px 0; color: #555;"><strong>Address:</strong> ${safeStreet}, ${safeCity}, CA ${safeZip}</p>
        </div>
        <p style="color: #555; font-size: 16px; line-height: 1.6;">
          If you have any questions in the meantime, feel free to call us at <strong>(530) 966-0752</strong> or reply to this email.
        </p>
        <p style="color: #888; font-size: 14px; margin-top: 32px; border-top: 1px solid #eee; padding-top: 16px;">
          — The Maid For Chico Team<br/>
          <a href="https://maidforchico.com" style="color: #b8860b;">maidforchico.com</a>
        </p>
      </div>
    `;

    try {
      const confirmRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: 'Maid For Chico <info@maidforchico.com>',
          to: [email],
          subject: `We've received your cleaning request!`,
          html: customerEmailHtml,
        }),
      });
      if (!confirmRes.ok) {
        console.error("Customer confirmation email failed:", await confirmRes.text());
      }
    } catch (err) {
      console.error("Customer confirmation email error:", err);
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  }
});
