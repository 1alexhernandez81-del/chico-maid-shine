import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALLOWED_ORIGINS = [
  'https://maidforchico.com',
  'https://www.maidforchico.com',
  'https://chico-maid-shine.lovable.app',
];

function getCorsHeaders(req: Request) {
  const origin = req.headers.get('Origin') || '';
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  };
}

const GOOGLE_REVIEWS_URL = "https://www.google.com/maps/place/Maid+For+Chico/@39.7238225,-122.007554,9z/data=!4m8!3m7!1s0x8082d9f21b5035d3:0x189f9dfb3b334fcb!8m2!3d39.7238225!4d-122.007554!9m1!1b1!16s%2Fg%2F11ghnxkzp4";
const YELP_REVIEWS_URL = "https://www.yelp.com/writeareview/biz/maid-for-chico-chico";

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: getCorsHeaders(req) });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Check if this is a direct send for a specific booking
    let body: any = {};
    try { body = await req.json(); } catch { /* empty body = cron mode */ }

    let bookingsToProcess: any[] = [];

    if (body.bookingId && body.email && body.name) {
      // Direct send mode — triggered from admin dashboard
      bookingsToProcess = [{ id: body.bookingId, email: body.email, name: body.name }];
      console.log(`Direct review request for ${body.email}`);
    } else {
      // Cron mode — find bookings completed yesterday
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];

      const { data: bookings, error } = await supabaseAdmin
        .from('bookings')
        .select('*')
        .eq('status', 'completed')
        .is('cancelled_at', null)
        .or(`scheduled_date.eq.${yesterdayStr},and(scheduled_date.is.null,preferred_date.eq.${yesterdayStr})`);

      if (error) {
        console.error("Query error:", error);
        return new Response(JSON.stringify({ error: error.message }), {
          status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
        });
      }

      bookingsToProcess = bookings || [];
      console.log(`Found ${bookingsToProcess.length} completed bookings from ${yesterdayStr} for review requests`);
    }

    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
    if (!RESEND_API_KEY) {
      return new Response(JSON.stringify({ error: "Email not configured" }), {
        status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    let sent = 0;
    for (const booking of bookingsToProcess) {
      const safeName = booking.name.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
      const firstName = safeName.split(' ')[0];

      const emailHtml = `
        <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px; background: #ffffff;">
          <p style="color: #333; font-size: 16px; line-height: 1.6; margin: 0 0 16px;">
            Hi ${firstName},
          </p>

          <p style="color: #333; font-size: 16px; line-height: 1.6; margin: 0 0 16px;">
            Thank you for choosing Maid For Chico! We hope everything looks great.
          </p>

          <p style="color: #333; font-size: 16px; line-height: 1.6; margin: 0 0 16px;">
            If you have a moment, we'd really appreciate a quick review — it helps other families in Chico find us:
          </p>

          <p style="color: #333; font-size: 16px; line-height: 1.6; margin: 0 0 8px;">
            → <a href="${GOOGLE_REVIEWS_URL}" style="color: #1a73e8;">Leave a Google review</a>
          </p>
          <p style="color: #333; font-size: 16px; line-height: 1.6; margin: 0 0 24px;">
            → <a href="${YELP_REVIEWS_URL}" style="color: #d32323;">Leave a Yelp review</a>
          </p>

          <p style="color: #333; font-size: 16px; line-height: 1.6; margin: 0 0 16px;">
            Thank you so much!
          </p>

          <p style="color: #333; font-size: 16px; line-height: 1.6; margin: 0 0 16px;">
            — Betty & the Maid For Chico team<br/>
            <span style="color: #888; font-size: 14px;">(530) 966-0752 · info@maidforchico.com</span>
          </p>

          <p style="color: #999; font-size: 13px; line-height: 1.5; margin: 16px 0 0; border-top: 1px solid #eee; padding-top: 12px;">
            P.S. Know someone who needs a cleaning? Refer a friend at <a href="https://maidforchico.com/refer" style="color: #1a73e8;">maidforchico.com/refer</a> — you both get $25 off!
          </p>
        </div>
      `;

      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: 'Maid For Chico <info@maidforchico.com>',
          to: [booking.email],
          subject: `How was your cleaning, ${firstName}? ⭐`,
          html: emailHtml,
          reply_to: 'info@maidforchico.com',
        }),
      });

      if (res.ok) {
        sent++;
        console.log(`Review request sent to ${booking.email}`);
      } else {
        console.error(`Failed to send review request for ${booking.id}:`, await res.text());
      }
    }

    return new Response(JSON.stringify({ success: true, sent }), {
      status: 200, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  }
});
