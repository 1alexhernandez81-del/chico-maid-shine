import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALLOWED_ORIGINS = [
  'https://maidforchico.com',
  'https://www.maidforchico.com',
  'https://chico-maid-shine.lovable.app',
];

function getCorsHeaders(req: Request) {
  const origin = req.headers.get('Origin') || '';
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };
}

async function getAccessToken(serviceAccount: any): Promise<string> {
  const header = { alg: "RS256", typ: "JWT" };
  const now = Math.floor(Date.now() / 1000);
  const claim = {
    iss: serviceAccount.client_email,
    scope: "https://www.googleapis.com/auth/calendar",
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
  };

  const encode = (obj: any) => btoa(JSON.stringify(obj)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  const unsignedToken = `${encode(header)}.${encode(claim)}`;

  const pemBody = serviceAccount.private_key
    .replace(/-----BEGIN PRIVATE KEY-----/, "")
    .replace(/-----END PRIVATE KEY-----/, "")
    .replace(/\s/g, "");
  const keyData = Uint8Array.from(atob(pemBody), (c) => c.charCodeAt(0));

  const cryptoKey = await crypto.subtle.importKey(
    "pkcs8",
    keyData,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );

  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    cryptoKey,
    new TextEncoder().encode(unsignedToken)
  );

  const sig = btoa(String.fromCharCode(...new Uint8Array(signature)))
    .replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");

  const jwt = `${unsignedToken}.${sig}`;

  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });

  const tokenData = await tokenRes.json();
  if (!tokenData.access_token) {
    console.error("Token error:", tokenData);
    throw new Error("Failed to get Google access token");
  }
  return tokenData.access_token;
}

function buildEventBody(booking: any) {
  // For estimates, use estimate_date/time; for jobs, use scheduled_date/time or preferred_date
  const isEstimate = booking.status === "estimate-scheduled" || 
    (booking.estimate_date && !booking.scheduled_date);
  
  const date = isEstimate 
    ? (booking.estimate_date || booking.preferred_date)
    : (booking.scheduled_date || booking.preferred_date);
  const time = isEstimate
    ? (booking.estimate_time || "09:00")
    : (booking.scheduled_time || booking.preferred_time || "09:00");
  
  const [year, month, day] = date.split("-").map(Number);
  const [hour, minute] = time.split(":").map(Number);

  const pad = (n: number) => n.toString().padStart(2, "0");
  const durationMinutes = isEstimate ? 30 : 120; // Estimates are 30 min, cleanings are 2 hours
  const startDt = `${year}-${pad(month)}-${pad(day)}T${pad(hour)}:${pad(minute)}:00`;
  const endTotalMin = hour * 60 + minute + durationMinutes;
  const endHour = Math.floor(endTotalMin / 60);
  const endMinute = endTotalMin % 60;
  const endDt = `${year}-${pad(month)}-${pad(day)}T${pad(endHour)}:${pad(endMinute)}:00`;

  const serviceType = (booking.service_type || "cleaning").replace("-", " ");
  const address = `${booking.street}, ${booking.city}, CA ${booking.zip}`;

  const summary = isEstimate 
    ? `📋 ESTIMATE — ${booking.name}`
    : `🧹 ${booking.name} – ${serviceType.charAt(0).toUpperCase() + serviceType.slice(1)}`;

  return {
    summary,
    description: [
      `Customer: ${booking.name}`,
      `Phone: ${booking.phone}`,
      `Email: ${booking.email}`,
      `Service: ${serviceType}`,
      `Frequency: ${booking.frequency}`,
      booking.sqft ? `Sqft: ${booking.sqft}` : "",
      booking.bedrooms ? `Bedrooms: ${booking.bedrooms}` : "",
      booking.bathrooms ? `Bathrooms: ${booking.bathrooms}` : "",
      booking.notes ? `Notes: ${booking.notes}` : "",
      booking.admin_notes ? `Admin Notes: ${booking.admin_notes}` : "",
      isEstimate ? `⚡ This is an ESTIMATE VISIT, not a cleaning.` : "",
    ].filter(Boolean).join("\n"),
    location: address,
    start: { dateTime: startDt, timeZone: "America/Los_Angeles" },
    end: { dateTime: endDt, timeZone: "America/Los_Angeles" },
    colorId: isEstimate ? "5" : "9",
  };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: getCorsHeaders(req) });
  }

  try {
    const { bookingId, action = "create" } = await req.json();
    if (!bookingId) {
      return new Response(JSON.stringify({ error: "Missing bookingId" }), {
        status: 400,
        headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const saJson = Deno.env.get("GOOGLE_SERVICE_ACCOUNT_JSON");
    const calendarId = Deno.env.get("GOOGLE_CALENDAR_ID");
    if (!saJson || !calendarId) {
      throw new Error("Missing GOOGLE_SERVICE_ACCOUNT_JSON or GOOGLE_CALENDAR_ID");
    }

    const serviceAccount = JSON.parse(saJson);
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: booking, error } = await supabaseAdmin
      .from("bookings")
      .select("*")
      .eq("id", bookingId)
      .single();

    if (error || !booking) {
      return new Response(JSON.stringify({ error: "Booking not found" }), {
        status: 404,
        headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const accessToken = await getAccessToken(serviceAccount);
    const baseUrl = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events`;
    const authHeaders = {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    };

    // DELETE
    if (action === "delete") {
      const eventId = booking.google_calendar_event_id;
      if (!eventId) {
        return new Response(JSON.stringify({ success: true, message: "No event to delete" }), {
          headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
        });
      }

      const delRes = await fetch(`${baseUrl}/${eventId}`, {
        method: "DELETE",
        headers: authHeaders,
      });

      if (!delRes.ok && delRes.status !== 404) {
        const body = await delRes.text();
        console.error("Delete error:", body);
        throw new Error("Failed to delete calendar event");
      }

      // Clear the stored event ID
      await supabaseAdmin
        .from("bookings")
        .update({ google_calendar_event_id: null } as any)
        .eq("id", bookingId);

      console.log("Event deleted:", eventId);
      return new Response(JSON.stringify({ success: true, deleted: eventId }), {
        headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    // UPDATE
    if (action === "update") {
      const eventId = booking.google_calendar_event_id;
      if (!eventId) {
        // No existing event — fall through to create
        console.log("No existing event, creating new one instead");
      } else {
        const event = buildEventBody(booking);
        const updRes = await fetch(`${baseUrl}/${eventId}`, {
          method: "PUT",
          headers: authHeaders,
          body: JSON.stringify(event),
        });

        if (updRes.status === 404) {
          console.log("Event not found on Google, creating new one");
        } else if (!updRes.ok) {
          const body = await updRes.json();
          console.error("Update error:", body);
          throw new Error(body.error?.message || "Calendar update error");
        } else {
          const updData = await updRes.json();
          console.log("Event updated:", updData.id);
          return new Response(JSON.stringify({ success: true, eventId: updData.id, action: "updated" }), {
            headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
          });
        }
      }
    }

    // CREATE (default, or fallback from update when event not found)
    const event = buildEventBody(booking);
    const calRes = await fetch(baseUrl, {
      method: "POST",
      headers: authHeaders,
      body: JSON.stringify(event),
    });

    const calData = await calRes.json();
    if (!calRes.ok) {
      console.error("Google Calendar API error:", calData);
      throw new Error(calData.error?.message || "Calendar API error");
    }

    // Store the event ID on the booking
    await supabaseAdmin
      .from("bookings")
      .update({ google_calendar_event_id: calData.id } as any)
      .eq("id", bookingId);

    console.log("Event created:", calData.id);
    return new Response(JSON.stringify({ success: true, eventId: calData.id, action: "created" }), {
      headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  }
});
