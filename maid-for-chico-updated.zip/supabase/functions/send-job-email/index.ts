import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALLOWED_ORIGINS = [
  'https://maidforchico.com',
  'https://www.maidforchico.com',
  'https://chico-maid-shine.lovable.app',
];

function getCorsHeaders(req: Request) {
  const origin = req.headers.get('Origin') || '';
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  };
}

function escapeHtml(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

function generateIcsContent(booking: any): string {
  const date = booking.scheduled_date || booking.preferred_date;
  const time = booking.scheduled_time || booking.preferred_time || '09:00';
  
  // Parse date and time
  const [year, month, day] = date.split('-').map(Number);
  const [hour, minute] = time.split(':').map(Number);
  
  const startDate = new Date(year, month - 1, day, hour, minute);
  const endDate = new Date(startDate.getTime() + 2 * 60 * 60 * 1000); // 2 hours

  const formatIcsDate = (d: Date) => {
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${pad(d.getHours())}${pad(d.getMinutes())}00`;
  };

  const serviceType = (booking.service_type || 'cleaning').replace('-', ' ');
  const address = `${booking.street}, ${booking.city}, CA ${booking.zip}`;

  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Maid For Chico//Booking//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:REQUEST',
    'BEGIN:VEVENT',
    `DTSTART:${formatIcsDate(startDate)}`,
    `DTEND:${formatIcsDate(endDate)}`,
    `SUMMARY:Cleaning Service - Maid For Chico`,
    `DESCRIPTION:${serviceType.charAt(0).toUpperCase() + serviceType.slice(1)} cleaning for ${booking.name}\\nAddress: ${address}\\nPhone: ${booking.phone}`,
    `LOCATION:${address}`,
    `UID:${booking.id}@maidforchico.com`,
    'STATUS:CONFIRMED',
    `ORGANIZER;CN=Maid For Chico:mailto:info@maidforchico.com`,
    `ATTENDEE;CN=${booking.name}:mailto:${booking.email}`,
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');
}

function generateGoogleCalendarUrl(booking: any): string {
  const date = booking.scheduled_date || booking.preferred_date;
  const time = booking.scheduled_time || booking.preferred_time || '09:00';
  
  const [year, month, day] = date.split('-').map(Number);
  const [hour, minute] = time.split(':').map(Number);
  
  const startDate = new Date(year, month - 1, day, hour, minute);
  const endDate = new Date(startDate.getTime() + 2 * 60 * 60 * 1000);

  const formatGcalDate = (d: Date) => {
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${pad(d.getHours())}${pad(d.getMinutes())}00`;
  };

  const serviceType = (booking.service_type || 'cleaning').replace('-', ' ');
  const address = `${booking.street}, ${booking.city}, CA ${booking.zip}`;

  const params = new URLSearchParams({
    action: 'TEMPLATE',
    text: 'Cleaning Service - Maid For Chico',
    dates: `${formatGcalDate(startDate)}/${formatGcalDate(endDate)}`,
    details: `${serviceType.charAt(0).toUpperCase() + serviceType.slice(1)} cleaning\nContact: ${booking.phone}\nEmail: info@maidforchico.com`,
    location: address,
  });

  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: getCorsHeaders(req) });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const data = await req.json();
    const { bookingId, type } = data;

    // For 'scheduled-internal' and 'cancellation' types, allow unauthenticated calls
    if (type !== 'scheduled-internal' && type !== 'cancellation') {
      const authHeader = req.headers.get('Authorization');
      if (!authHeader) {
        return new Response(JSON.stringify({ error: "Unauthorized" }), {
          status: 401, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
        });
      }

      const token = authHeader.replace('Bearer ', '');
      const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token);
      if (authError || !user) {
        return new Response(JSON.stringify({ error: "Unauthorized" }), {
          status: 401, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
        });
      }

      const { data: roles } = await supabaseAdmin
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .eq('role', 'admin');

      if (!roles || roles.length === 0) {
        return new Response(JSON.stringify({ error: "Forbidden" }), {
          status: 403, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
        });
      }
    }

    if (!bookingId || !type || !['quote', 'receipt', 'approval', 'scheduled', 'scheduled-internal', 'cancellation'].includes(type)) {
      return new Response(JSON.stringify({ error: "Missing bookingId or invalid type" }), {
        status: 400, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const effectiveType = type === 'scheduled-internal' ? 'scheduled' : type;

    const { data: booking, error: bookingError } = await supabaseAdmin
      .from('bookings')
      .select('*')
      .eq('id', bookingId)
      .single();

    if (bookingError || !booking) {
      return new Response(JSON.stringify({ error: "Booking not found" }), {
        status: 404, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
    if (!RESEND_API_KEY) {
      return new Response(JSON.stringify({ error: "Email service not configured" }), {
        status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const safeName = escapeHtml(booking.name);
    const lineItems = Array.isArray(booking.line_items) ? booking.line_items : [];
    const total = booking.total_price || lineItems.reduce((sum: number, item: any) => sum + (item.amount || 0), 0);

    if (effectiveType === 'scheduled') {
      // Send scheduled email to BOTH customer and business
      const scheduledDate = booking.scheduled_date || booking.preferred_date;
      const scheduledTime = booking.scheduled_time || booking.preferred_time || 'Morning';
      const googleCalUrl = generateGoogleCalendarUrl(booking);
      
      const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
      const icsUrl = `${SUPABASE_URL}/functions/v1/generate-ics?bookingId=${booking.id}`;
      
      // Build confirm URL
      const siteUrl = 'https://maidforchico.com';
      const confirmUrl = `${siteUrl}/confirm-appointment?token=${booking.confirmation_token}`;

      const customerEmailHtml = buildScheduledEmail({
        safeName,
        scheduledDate,
        scheduledTime,
        booking,
        googleCalUrl,
        icsUrl,
        confirmUrl,
        isCustomer: true,
        lineItems,
        total,
      });

      const businessEmailHtml = buildScheduledEmail({
        safeName,
        scheduledDate,
        scheduledTime,
        booking,
        googleCalUrl,
        icsUrl,
        confirmUrl: null,
        isCustomer: false,
        lineItems,
        total,
      });

      // Generate ICS attachment content
      const icsContent = generateIcsContent(booking);

      // Send to customer
      const customerRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: 'Maid For Chico <info@maidforchico.com>',
          to: [booking.email],
          subject: `Your Cleaning is Scheduled — ${scheduledDate}`,
          html: customerEmailHtml,
          reply_to: 'info@maidforchico.com',
          attachments: [{
            filename: 'appointment.ics',
            content: btoa(icsContent),
          }],
        }),
      });

      // Send to business
      const businessRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: 'Maid For Chico <info@maidforchico.com>',
          to: ['info@maidforchico.com'],
          subject: `Job Scheduled: ${booking.name} — ${scheduledDate}`,
          html: businessEmailHtml,
          reply_to: booking.email,
          attachments: [{
            filename: 'appointment.ics',
            content: btoa(icsContent),
          }],
        }),
      });

      if (!customerRes.ok || !businessRes.ok) {
        const err = await customerRes.json().catch(() => ({}));
        console.error("Resend error:", err);
        return new Response(JSON.stringify({ error: "Failed to send scheduled emails" }), {
          status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({ success: true }), {
        status: 200, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    if (effectiveType === 'cancellation') {
      const scheduledDate = booking.scheduled_date || booking.preferred_date;
      const scheduledTime = booking.scheduled_time || booking.preferred_time || 'Morning';
      const address = `${escapeHtml(booking.street)}, ${escapeHtml(booking.city)}, CA ${escapeHtml(booking.zip)}`;
      const serviceType = escapeHtml((booking.service_type || '').replace('-', ' '));
      const feeNote = booking.cancellation_fee && booking.cancellation_fee > 0
        ? `<tr><td style="padding: 4px 0; color: #888;">💰 Late Fee</td><td style="padding: 4px 0; color: #e53e3e; text-align: right; font-weight: bold;">$${Number(booking.cancellation_fee).toFixed(2)}</td></tr>`
        : `<tr><td colspan="2" style="padding: 4px 0; color: #4CAF50;">✅ No cancellation fee (cancelled 24+ hours in advance)</td></tr>`;

      const cancellationHtml = `
        <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px; background: #ffffff;">
          <div style="text-align: center; margin-bottom: 32px;">
            <h1 style="color: #1a1a1a; font-size: 28px; margin: 0; letter-spacing: -0.5px;">Maid For Chico</h1>
            <p style="color: #e53e3e; font-size: 12px; text-transform: uppercase; letter-spacing: 2px; margin-top: 4px;">APPOINTMENT CANCELLED</p>
          </div>

          <div style="background: #fff5f5; border-left: 4px solid #e53e3e; padding: 16px; border-radius: 4px; margin-bottom: 24px;">
            <p style="margin: 0; color: #333; font-size: 16px;">
              ❌ <strong>${safeName}</strong> has cancelled their appointment.
            </p>
          </div>

          <div style="background: #fafafa; border-radius: 8px; padding: 24px; margin-bottom: 24px;">
            <h3 style="color: #1a1a1a; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; margin: 0 0 16px;">Cancelled Appointment Details</h3>
            <table style="width: 100%; font-size: 14px;">
              <tr><td style="padding: 4px 0; color: #888;">📅 Date</td><td style="padding: 4px 0; color: #333; text-align: right; font-weight: bold;">${escapeHtml(scheduledDate)}</td></tr>
              <tr><td style="padding: 4px 0; color: #888;">🕐 Time</td><td style="padding: 4px 0; color: #333; text-align: right; text-transform: capitalize;">${escapeHtml(scheduledTime)}</td></tr>
              <tr><td style="padding: 4px 0; color: #888;">📍 Address</td><td style="padding: 4px 0; color: #333; text-align: right;">${address}</td></tr>
              <tr><td style="padding: 4px 0; color: #888;">🧹 Service</td><td style="padding: 4px 0; color: #333; text-align: right; text-transform: capitalize;">${serviceType}</td></tr>
              <tr><td style="padding: 4px 0; color: #888;">📞 Phone</td><td style="padding: 4px 0; color: #333; text-align: right;">${escapeHtml(booking.phone)}</td></tr>
              <tr><td style="padding: 4px 0; color: #888;">✉️ Email</td><td style="padding: 4px 0; color: #333; text-align: right;">${escapeHtml(booking.email)}</td></tr>
              ${feeNote}
            </table>
          </div>

          <div style="text-align: center; border-top: 1px solid #eee; padding-top: 24px; margin-top: 32px;">
            <p style="color: #888; font-size: 13px; margin: 0;">
              Maid For Chico<br/>(530) 966-0752 · info@maidforchico.com<br/>
              <a href="https://maidforchico.com" style="color: #b8860b;">maidforchico.com</a>
            </p>
          </div>
        </div>
      `;

      const cancelRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: 'Maid For Chico <info@maidforchico.com>',
          to: ['info@maidforchico.com'],
          subject: `⚠️ Cancellation: ${booking.name} — ${scheduledDate}`,
          html: cancellationHtml,
          reply_to: booking.email,
        }),
      });

      if (!cancelRes.ok) {
        const err = await cancelRes.json().catch(() => ({}));
        console.error("Resend cancellation error:", err);
        return new Response(JSON.stringify({ error: "Failed to send cancellation email" }), {
          status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({ success: true }), {
        status: 200, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    // Original quote/receipt/approval flow
    const { subject, headerText, introText } = getEmailContent(effectiveType, safeName);

    const lineItemsHtml = lineItems.length > 0
      ? lineItems.map((item: any) => `
          <tr>
            <td style="padding: 8px 0; border-bottom: 1px solid #eee; color: #333;">${escapeHtml(item.description || '')}</td>
            <td style="padding: 8px 0; border-bottom: 1px solid #eee; text-align: right; color: #333;">$${(item.amount || 0).toFixed(2)}</td>
          </tr>
        `).join('')
      : `<tr><td colspan="2" style="padding: 8px 0; color: #888;">No line items specified</td></tr>`;

    const typeLabel = effectiveType === 'approval' ? 'BOOKING APPROVED' : effectiveType === 'quote' ? 'SERVICE QUOTE' : 'SERVICE RECEIPT';

    const pricingSection = effectiveType === 'approval' && lineItems.length === 0 ? '' : `
      <div style="margin-bottom: 24px;">
        <h3 style="color: #1a1a1a; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; margin: 0 0 16px;">
          ${effectiveType === 'quote' ? 'Quote Breakdown' : effectiveType === 'approval' ? 'Estimated Pricing' : 'Charges'}
        </h3>
        <table style="width: 100%; font-size: 14px; border-collapse: collapse;">
          ${lineItemsHtml}
          <tr>
            <td style="padding: 12px 0 0; font-weight: bold; color: #1a1a1a; font-size: 16px;">Total</td>
            <td style="padding: 12px 0 0; font-weight: bold; color: #b8860b; font-size: 20px; text-align: right;">$${total.toFixed(2)}</td>
          </tr>
        </table>
      </div>
    `;

    const deposit = total > 0 ? (total * 0.25) : 0;
    const ctaSection = effectiveType === 'approval' ? `
      <div style="background: #f0f7ee; border-left: 4px solid #4CAF50; padding: 16px; border-radius: 4px; margin-bottom: 24px;">
        <p style="margin: 0; color: #333; font-size: 14px;">
          ✅ <strong>Your booking has been approved!</strong> We'll be there on <strong>${escapeHtml(booking.preferred_date)}</strong>.
          If you need to reschedule, call us at <strong>(530) 966-0752</strong>.
        </p>
      </div>
      ${deposit > 0 ? `
      <div style="background: #fffbeb; border-left: 4px solid #b8860b; padding: 16px; border-radius: 4px; margin-bottom: 24px;">
        <p style="margin: 0 0 8px; color: #333; font-size: 14px; font-weight: bold;">💳 Next Step: 25% Deposit via Zelle</p>
        <p style="margin: 0; color: #555; font-size: 14px;">
          A deposit of <strong>$${deposit.toFixed(2)}</strong> is required to secure your cleaning date. Please send your deposit via <strong>Zelle</strong> to <strong>(530) 966-0752</strong>. Once received, we'll finalize your booking and schedule your cleaning. The remaining balance of <strong>$${(total - deposit).toFixed(2)}</strong> is due on the day of your cleaning.
        </p>
      </div>
      ` : ''}
    ` : effectiveType === 'quote' ? `
      <div style="background: #f0f7ee; border-left: 4px solid #4CAF50; padding: 16px; border-radius: 4px; margin-bottom: 24px;">
        <p style="margin: 0; color: #333; font-size: 14px;">
          This quote is valid for 30 days. To confirm, simply reply to this email or call us at <strong>(530) 966-0752</strong>.
        </p>
      </div>
    ` : `
      <div style="background: #f0f4f8; border-left: 4px solid #b8860b; padding: 16px; border-radius: 4px; margin-bottom: 24px;">
        <p style="margin: 0; color: #333; font-size: 14px;">
          Thank you for your business! If you have any questions about this receipt, please call us at <strong>(530) 966-0752</strong>.
        </p>
      </div>
    `;

    const emailHtml = `
      <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px; background: #ffffff;">
        <div style="text-align: center; margin-bottom: 32px;">
          <h1 style="color: #1a1a1a; font-size: 28px; margin: 0; letter-spacing: -0.5px;">Maid For Chico</h1>
          <p style="color: #b8860b; font-size: 12px; text-transform: uppercase; letter-spacing: 2px; margin-top: 4px;">${typeLabel}</p>
        </div>
        <p style="color: #333; font-size: 16px; line-height: 1.6; margin-bottom: 24px;">${headerText}</p>
        <p style="color: #555; font-size: 15px; line-height: 1.6; margin-bottom: 28px;">${introText}</p>
        <div style="background: #fafafa; border-radius: 8px; padding: 24px; margin-bottom: 24px;">
          <h3 style="color: #1a1a1a; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; margin: 0 0 16px;">Service Details</h3>
          <table style="width: 100%; font-size: 14px;">
            <tr><td style="padding: 4px 0; color: #888;">Service</td><td style="padding: 4px 0; color: #333; text-align: right; text-transform: capitalize;">${escapeHtml((booking.service_type || '').replace('-', ' '))}</td></tr>
            <tr><td style="padding: 4px 0; color: #888;">Frequency</td><td style="padding: 4px 0; color: #333; text-align: right; text-transform: capitalize;">${escapeHtml((booking.frequency || '').replace('-', ' '))}</td></tr>
            <tr><td style="padding: 4px 0; color: #888;">Address</td><td style="padding: 4px 0; color: #333; text-align: right;">${escapeHtml(booking.street)}, ${escapeHtml(booking.city)}, CA ${escapeHtml(booking.zip)}</td></tr>
            <tr><td style="padding: 4px 0; color: #888;">Date</td><td style="padding: 4px 0; color: #333; text-align: right;">${escapeHtml(booking.preferred_date)}</td></tr>
          </table>
        </div>
        ${pricingSection}
        ${ctaSection}
        <div style="text-align: center; border-top: 1px solid #eee; padding-top: 24px; margin-top: 32px;">
          <p style="color: #888; font-size: 13px; margin: 0;">
            Maid For Chico<br/>(530) 966-0752 · info@maidforchico.com<br/>
            <a href="https://maidforchico.com" style="color: #b8860b;">maidforchico.com</a>
          </p>
        </div>
      </div>
    `;

    const resendRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Maid For Chico <info@maidforchico.com>',
        to: [booking.email],
        subject,
        html: emailHtml,
        reply_to: 'info@maidforchico.com',
      }),
    });

    const resendData = await resendRes.json();

    if (!resendRes.ok) {
      console.error("Resend API error:", resendData);
      return new Response(JSON.stringify({ error: "Failed to send email" }), {
        status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  }
});

function getEmailContent(type: string, safeName: string) {
  if (type === 'approval') {
    return {
      subject: 'Your Booking is Approved — Maid For Chico',
      headerText: `Great news, ${safeName}! Your cleaning booking has been approved! 🎉`,
      introText: `We're excited to confirm your appointment. Here are the details of your upcoming service.`,
    };
  }
  if (type === 'quote') {
    return {
      subject: 'Cleaning Quote from Maid For Chico',
      headerText: `Hi ${safeName}, here's your cleaning quote!`,
      introText: `Thank you for your interest in our cleaning services. Below is a detailed quote for your review.`,
    };
  }
  return {
    subject: 'Receipt from Maid For Chico',
    headerText: `Hi ${safeName}, here's your receipt!`,
    introText: `Thank you for choosing Maid For Chico! Below is a summary of the completed service.`,
  };
}

interface ScheduledEmailParams {
  safeName: string;
  scheduledDate: string;
  scheduledTime: string;
  booking: any;
  googleCalUrl: string;
  icsUrl: string;
  confirmUrl: string | null;
  isCustomer: boolean;
  lineItems: any[];
  total: number;
}

function buildScheduledEmail(params: ScheduledEmailParams): string {
  const { safeName, scheduledDate, scheduledTime, booking, googleCalUrl, icsUrl, confirmUrl, isCustomer, lineItems, total } = params;
  
  const address = `${escapeHtml(booking.street)}, ${escapeHtml(booking.city)}, CA ${escapeHtml(booking.zip)}`;
  const serviceType = escapeHtml((booking.service_type || '').replace('-', ' '));
  const frequency = escapeHtml((booking.frequency || '').replace('-', ' '));

  const greeting = isCustomer
    ? `Hi ${safeName}, your cleaning has been scheduled! 📅`
    : `New job scheduled for ${safeName}`;

  const intro = isCustomer
    ? `We've confirmed your cleaning appointment. Here are the details:`
    : `A new cleaning job has been scheduled. Details below:`;

  const pricingHtml = total > 0 ? `
    <tr><td style="padding: 4px 0; color: #888;">Estimated Total</td><td style="padding: 4px 0; color: #b8860b; text-align: right; font-weight: bold; font-size: 16px;">$${total.toFixed(2)}</td></tr>
  ` : '';

  const confirmSection = isCustomer && confirmUrl ? `
    <div style="background: #f0f7ee; border-left: 4px solid #4CAF50; padding: 16px; border-radius: 4px; margin-bottom: 24px;">
      <p style="margin: 0 0 12px; color: #333; font-size: 14px;">
        <strong>Please confirm your appointment:</strong>
      </p>
      <a href="${confirmUrl}" style="display: inline-block; background: #4CAF50; color: #ffffff; text-decoration: none; padding: 12px 28px; border-radius: 6px; font-weight: bold; font-size: 14px;">
        ✅ Yes, I Confirm
      </a>
      <p style="margin: 12px 0 0; color: #666; font-size: 12px;">
        No worries if you can't click — your appointment is already on the books!
      </p>
    </div>
  ` : '';

  return `
    <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px; background: #ffffff;">
      <div style="text-align: center; margin-bottom: 32px;">
        <h1 style="color: #1a1a1a; font-size: 28px; margin: 0; letter-spacing: -0.5px;">Maid For Chico</h1>
        <p style="color: #b8860b; font-size: 12px; text-transform: uppercase; letter-spacing: 2px; margin-top: 4px;">APPOINTMENT SCHEDULED</p>
      </div>

      <p style="color: #333; font-size: 16px; line-height: 1.6; margin-bottom: 24px;">${greeting}</p>
      <p style="color: #555; font-size: 15px; line-height: 1.6; margin-bottom: 28px;">${intro}</p>

      <div style="background: #fafafa; border-radius: 8px; padding: 24px; margin-bottom: 24px;">
        <h3 style="color: #1a1a1a; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; margin: 0 0 16px;">Appointment Details</h3>
        <table style="width: 100%; font-size: 14px;">
          <tr><td style="padding: 4px 0; color: #888;">📅 Date</td><td style="padding: 4px 0; color: #333; text-align: right; font-weight: bold;">${escapeHtml(scheduledDate)}</td></tr>
          <tr><td style="padding: 4px 0; color: #888;">🕐 Time</td><td style="padding: 4px 0; color: #333; text-align: right; font-weight: bold; text-transform: capitalize;">${escapeHtml(scheduledTime)}</td></tr>
          <tr><td style="padding: 4px 0; color: #888;">📍 Address</td><td style="padding: 4px 0; color: #333; text-align: right;">${address}</td></tr>
          <tr><td style="padding: 4px 0; color: #888;">🧹 Service</td><td style="padding: 4px 0; color: #333; text-align: right; text-transform: capitalize;">${serviceType}</td></tr>
          <tr><td style="padding: 4px 0; color: #888;">🔄 Frequency</td><td style="padding: 4px 0; color: #333; text-align: right; text-transform: capitalize;">${frequency}</td></tr>
          ${isCustomer ? '' : `<tr><td style="padding: 4px 0; color: #888;">📞 Phone</td><td style="padding: 4px 0; color: #333; text-align: right;">${escapeHtml(booking.phone)}</td></tr>`}
          ${isCustomer ? '' : `<tr><td style="padding: 4px 0; color: #888;">✉️ Email</td><td style="padding: 4px 0; color: #333; text-align: right;">${escapeHtml(booking.email)}</td></tr>`}
          ${pricingHtml}
        </table>
      </div>

      ${confirmSection}

      <!-- Calendar Links -->
      <div style="text-align: center; margin-bottom: 28px;">
        <p style="color: #555; font-size: 13px; margin-bottom: 12px;">Add to your calendar:</p>
        <a href="${googleCalUrl}" target="_blank" style="display: inline-block; background: #4285f4; color: #ffffff; text-decoration: none; padding: 10px 24px; border-radius: 6px; font-size: 14px; font-weight: bold; margin-right: 8px;">
          📅 Google Calendar
        </a>
        <a href="${icsUrl}" target="_blank" style="display: inline-block; background: #333333; color: #ffffff; text-decoration: none; padding: 10px 24px; border-radius: 6px; font-size: 14px; font-weight: bold;">
          📥 Download .ics
        </a>
      </div>

      ${booking.notes ? `
        <div style="background: #fffbeb; border-left: 4px solid #b8860b; padding: 16px; border-radius: 4px; margin-bottom: 24px;">
          <p style="margin: 0; color: #333; font-size: 13px;">
            <strong>Notes:</strong> ${escapeHtml(booking.notes)}
          </p>
        </div>
      ` : ''}

      <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 16px; border-radius: 4px; margin-bottom: 24px;">
        <p style="margin: 0; color: #856404; font-size: 13px;">
          <strong>⚠️ Cancellation Policy:</strong> Cancellations within 24 hours of your scheduled appointment are subject to a <strong>$50 cancellation fee</strong>.
        </p>
      </div>

      <div style="background: #f8f9fa; border-radius: 8px; padding: 16px; margin-bottom: 24px; text-align: center;">
        <p style="margin: 0; color: #555; font-size: 14px;">
          Need to reschedule? Call us at <strong style="color: #1a1a1a;">(530) 966-0752</strong>
        </p>
      </div>

      <div style="text-align: center; border-top: 1px solid #eee; padding-top: 24px; margin-top: 32px;">
        <p style="color: #888; font-size: 13px; margin: 0;">
          Maid For Chico<br/>(530) 966-0752 · info@maidforchico.com<br/>
          <a href="https://maidforchico.com" style="color: #b8860b;">maidforchico.com</a>
        </p>
      </div>
    </div>
  `;
}
