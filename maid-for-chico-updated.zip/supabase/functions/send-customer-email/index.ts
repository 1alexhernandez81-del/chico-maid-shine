import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALLOWED_ORIGINS = [
  'https://maidforchico.com',
  'https://www.maidforchico.com',
  'https://chico-maid-shine.lovable.app',
];

function getCorsHeaders(req: Request) {
  const origin = req.headers.get('Origin') || '';
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
  };
}

function escapeHtml(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: getCorsHeaders(req) });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Verify admin
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const { data: roles } = await supabaseAdmin
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'admin');

    if (!roles || roles.length === 0) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const { customerEmail, customerName, subject, body, ctaUrl, ctaLabel, inReplyTo, references } = await req.json();

    if (!customerEmail || !subject || !body) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
    if (!RESEND_API_KEY) {
      return new Response(JSON.stringify({ error: "Email service not configured" }), {
        status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    const safeName = escapeHtml(customerName || '');
    // Convert URLs in the body to clickable links, then convert newlines to <br/>
    let safeBody = escapeHtml(body);
    // Replace approve-quote URLs with a styled button
    if (ctaUrl && ctaLabel) {
      const safeCtaUrl = escapeHtml(ctaUrl);
      const safeCtaLabel = escapeHtml(ctaLabel);
      safeBody = safeBody.replace(
        new RegExp(escapeHtml(ctaUrl).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'),
        ''
      );
      safeBody = safeBody.replace(/\n/g, '<br/>');
      safeBody += `
        <div style="text-align: center; margin: 28px 0;">
          <a href="${safeCtaUrl}" style="display: inline-block; background-color: #059669; color: #ffffff; padding: 16px 40px; font-size: 18px; font-weight: 700; text-decoration: none; border-radius: 10px; letter-spacing: 0.3px;">${safeCtaLabel}</a>
        </div>
      `;
    } else {
      safeBody = safeBody.replace(/\n/g, '<br/>');
    }

    const emailHtml = `
      <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px; background: #ffffff;">
        <div style="text-align: center; margin-bottom: 32px;">
          <h1 style="color: #1a1a1a; font-size: 28px; margin: 0; letter-spacing: -0.5px;">Maid For Chico</h1>
        </div>
        <p style="color: #333; font-size: 16px; line-height: 1.6; margin-bottom: 24px;">Hi ${safeName},</p>
        <div style="color: #555; font-size: 15px; line-height: 1.8; margin-bottom: 28px;">
          ${safeBody}
        </div>
        <div style="text-align: center; border-top: 1px solid #eee; padding-top: 24px; margin-top: 32px;">
          <p style="color: #888; font-size: 13px; margin: 0;">
            Maid For Chico<br/>(530) 966-0752 · info@maidforchico.com<br/>
            <a href="https://maidforchico.com" style="color: #b8860b;">maidforchico.com</a>
          </p>
        </div>
      </div>
    `;

    // Build Resend payload with optional threading headers
    const resendPayload: Record<string, unknown> = {
      from: 'Maid For Chico <info@maidforchico.com>',
      to: [customerEmail],
      bcc: ['info@maidforchico.com'],
      subject: escapeHtml(subject),
      html: emailHtml,
      reply_to: 'info@maidforchico.com',
    };

    // Add email threading headers if provided
    const headers: Record<string, string> = {};
    if (inReplyTo) {
      headers['In-Reply-To'] = inReplyTo;
    }
    if (references) {
      headers['References'] = references;
    }
    if (Object.keys(headers).length > 0) {
      resendPayload.headers = headers;
    }

    const resendRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(resendPayload),
    });

    const resendData = await resendRes.json();

    if (!resendRes.ok) {
      console.error("Resend API error:", resendData);
      return new Response(JSON.stringify({ error: "Failed to send email" }), {
        status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    // Return the Resend message ID so callers can store it for threading
    const messageId = resendData.id ? `<${resendData.id}@resend.dev>` : null;

    return new Response(JSON.stringify({ success: true, messageId }), {
      status: 200, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  }
});
