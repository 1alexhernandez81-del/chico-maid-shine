import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALLOWED_ORIGINS = [
  'https://maidforchico.com',
  'https://www.maidforchico.com',
  'https://chico-maid-shine.lovable.app',
];

function getCorsHeaders(req: Request) {
  const origin = req.headers.get('Origin') || '';
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: getCorsHeaders(req) });
  }

  try {
    const url = new URL(req.url);
    const bookingId = url.searchParams.get('bookingId');

    if (!bookingId) {
      return new Response('Missing bookingId', { status: 400 });
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { data: booking, error } = await supabaseAdmin
      .from('bookings')
      .select('*')
      .eq('id', bookingId)
      .single();

    if (error || !booking) {
      return new Response('Booking not found', { status: 404 });
    }

    const date = booking.scheduled_date || booking.preferred_date;
    const time = booking.scheduled_time || booking.preferred_time || '09:00';
    
    const [year, month, day] = date.split('-').map(Number);
    const [hour, minute] = time.split(':').map(Number);
    
    const startDate = new Date(year, month - 1, day, hour, minute);
    const endDate = new Date(startDate.getTime() + 2 * 60 * 60 * 1000);

    const formatIcsDate = (d: Date) => {
      const pad = (n: number) => n.toString().padStart(2, '0');
      return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${pad(d.getHours())}${pad(d.getMinutes())}00`;
    };

    const serviceType = (booking.service_type || 'cleaning').replace('-', ' ');
    const address = `${booking.street}, ${booking.city}, CA ${booking.zip}`;

    const ics = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Maid For Chico//Booking//EN',
      'CALSCALE:GREGORIAN',
      'METHOD:REQUEST',
      'BEGIN:VEVENT',
      `DTSTART:${formatIcsDate(startDate)}`,
      `DTEND:${formatIcsDate(endDate)}`,
      `SUMMARY:Cleaning Service - Maid For Chico`,
      `DESCRIPTION:${serviceType.charAt(0).toUpperCase() + serviceType.slice(1)} cleaning for ${booking.name}\\nAddress: ${address}\\nPhone: ${booking.phone}`,
      `LOCATION:${address}`,
      `UID:${booking.id}@maidforchico.com`,
      'STATUS:CONFIRMED',
      `ORGANIZER;CN=Maid For Chico:mailto:info@maidforchico.com`,
      `ATTENDEE;CN=${booking.name}:mailto:${booking.email}`,
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');

    return new Response(ics, {
      status: 200,
      headers: {
        ...getCorsHeaders(req),
        'Content-Type': 'text/calendar; charset=utf-8',
        'Content-Disposition': 'attachment; filename="appointment.ics"',
      },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response('Internal server error', { status: 500 });
  }
});
