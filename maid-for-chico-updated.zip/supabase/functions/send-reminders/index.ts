import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const ALLOWED_ORIGINS = [
  'https://maidforchico.com',
  'https://www.maidforchico.com',
  'https://chico-maid-shine.lovable.app',
];

function getCorsHeaders(req: Request) {
  const origin = req.headers.get('Origin') || '';
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: getCorsHeaders(req) });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Find bookings scheduled for tomorrow that haven't been reminded
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split('T')[0]; // YYYY-MM-DD

    const { data: bookings, error } = await supabaseAdmin
      .from('bookings')
      .select('*')
      .in('status', ['scheduled', 'approved'])
      .is('cancelled_at', null)
      .eq('reminder_sent', false)
      .or(`scheduled_date.eq.${tomorrowStr},and(scheduled_date.is.null,preferred_date.eq.${tomorrowStr})`);

    if (error) {
      console.error("Query error:", error);
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    console.log(`Found ${bookings?.length || 0} bookings to remind for ${tomorrowStr}`);

    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
    if (!RESEND_API_KEY) {
      return new Response(JSON.stringify({ error: "Email not configured" }), {
        status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
      });
    }

    let sent = 0;
    for (const booking of (bookings || [])) {
      const scheduledDate = booking.scheduled_date || booking.preferred_date;
      const scheduledTime = booking.scheduled_time || booking.preferred_time || 'Morning';
      const address = `${booking.street}, ${booking.city}, CA ${booking.zip}`;
      const serviceType = (booking.service_type || 'cleaning').replace('-', ' ');
      const safeName = booking.name.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
      
      const siteUrl = 'https://maidforchico.com';
      const confirmUrl = `${siteUrl}/confirm-appointment?token=${booking.confirmation_token}`;

      const emailHtml = `
        <div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px; background: #ffffff;">
          <div style="text-align: center; margin-bottom: 32px;">
            <h1 style="color: #1a1a1a; font-size: 28px; margin: 0; letter-spacing: -0.5px;">Maid For Chico</h1>
            <p style="color: #b8860b; font-size: 12px; text-transform: uppercase; letter-spacing: 2px; margin-top: 4px;">APPOINTMENT REMINDER</p>
          </div>

          <p style="color: #333; font-size: 16px; line-height: 1.6; margin-bottom: 24px;">
            Hi ${safeName}, this is a friendly reminder that your cleaning is <strong>tomorrow</strong>! 🧹
          </p>

          <div style="background: #fafafa; border-radius: 8px; padding: 24px; margin-bottom: 24px;">
            <h3 style="color: #1a1a1a; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; margin: 0 0 16px;">Appointment Details</h3>
            <table style="width: 100%; font-size: 14px;">
              <tr><td style="padding: 4px 0; color: #888;">📅 Date</td><td style="padding: 4px 0; color: #333; text-align: right; font-weight: bold;">${scheduledDate}</td></tr>
              <tr><td style="padding: 4px 0; color: #888;">🕐 Time</td><td style="padding: 4px 0; color: #333; text-align: right; font-weight: bold; text-transform: capitalize;">${scheduledTime}</td></tr>
              <tr><td style="padding: 4px 0; color: #888;">📍 Address</td><td style="padding: 4px 0; color: #333; text-align: right;">${address}</td></tr>
              <tr><td style="padding: 4px 0; color: #888;">🧹 Service</td><td style="padding: 4px 0; color: #333; text-align: right; text-transform: capitalize;">${serviceType}</td></tr>
            </table>
          </div>

          <div style="text-align: center; margin-bottom: 24px;">
            <a href="${confirmUrl}" style="display: inline-block; background: #4CAF50; color: #ffffff; text-decoration: none; padding: 12px 28px; border-radius: 6px; font-weight: bold; font-size: 14px;">
              ✅ Confirm Appointment
            </a>
          </div>

          <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 16px; border-radius: 4px; margin-bottom: 24px;">
            <p style="margin: 0; color: #856404; font-size: 13px;">
              <strong>⚠️ Cancellation Policy:</strong> Cancellations within 24 hours of your scheduled appointment are subject to a <strong>$50 cancellation fee</strong>.
            </p>
          </div>

          <div style="background: #f8f9fa; border-radius: 8px; padding: 16px; margin-bottom: 24px; text-align: center;">
            <p style="margin: 0; color: #555; font-size: 14px;">
              Need to reschedule? Call us ASAP at <strong style="color: #1a1a1a;">(530) 966-0752</strong>
            </p>
          </div>

          <div style="text-align: center; border-top: 1px solid #eee; padding-top: 24px; margin-top: 32px;">
            <p style="color: #888; font-size: 13px; margin: 0;">
              Maid For Chico<br/>(530) 966-0752 · info@maidforchico.com<br/>
              <a href="https://maidforchico.com" style="color: #b8860b;">maidforchico.com</a>
            </p>
          </div>
        </div>
      `;

      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: 'Maid For Chico <info@maidforchico.com>',
          to: [booking.email],
          subject: `Reminder: Your Cleaning is Tomorrow — ${scheduledDate}`,
          html: emailHtml,
          reply_to: 'info@maidforchico.com',
        }),
      });

      if (res.ok) {
        await supabaseAdmin.from('bookings').update({ reminder_sent: true }).eq('id', booking.id);
        sent++;
      } else {
        console.error(`Failed to send reminder for booking ${booking.id}:`, await res.text());
      }
    }

    // Also send reminder to business
    if (sent > 0) {
      const names = (bookings || []).map((b: any) => b.name).join(', ');
      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: 'Maid For Chico <info@maidforchico.com>',
          to: ['info@maidforchico.com'],
          subject: `📋 Tomorrow's Jobs: ${sent} appointment(s)`,
          html: `<p>You have <strong>${sent}</strong> cleaning appointment(s) scheduled for tomorrow.</p><p>Clients: ${names}</p><p><a href="https://maidforchico.com/admin">View in Dashboard</a></p>`,
          reply_to: 'info@maidforchico.com',
        }),
      });
    }

    return new Response(JSON.stringify({ success: true, reminded: sent }), {
      status: 200, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500, headers: { ...getCorsHeaders(req), "Content-Type": "application/json" },
    });
  }
});
