
DROP FUNCTION IF EXISTS public.get_booking_by_token(uuid);

CREATE FUNCTION public.get_booking_by_token(_token uuid)
 RETURNS TABLE(id uuid, name text, email text, phone text, street text, city text, zip text, service_type text, frequency text, preferred_date text, preferred_time text, scheduled_date text, scheduled_time text, confirmed_at timestamp with time zone, status text, total_price numeric, sqft text, bedrooms text, bathrooms text)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT id, name, email, phone, street, city, zip, service_type, frequency,
         preferred_date, preferred_time, scheduled_date, scheduled_time, confirmed_at, status,
         total_price, sqft, bedrooms, bathrooms
  FROM public.bookings
  WHERE confirmation_token = _token
  LIMIT 1;
$function$;
