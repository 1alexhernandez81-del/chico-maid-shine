CREATE TABLE public.rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL,
  window_start timestamp with time zone NOT NULL DEFAULT now(),
  request_count integer NOT NULL DEFAULT 1
);

CREATE INDEX idx_rate_limits_key_window ON public.rate_limits (key, window_start);

ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;