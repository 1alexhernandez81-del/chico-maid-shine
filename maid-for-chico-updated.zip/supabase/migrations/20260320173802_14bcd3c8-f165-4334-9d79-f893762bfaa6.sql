
-- Drop overly permissive policies
DROP POLICY IF EXISTS "Anyone can view booking by confirmation token" ON public.bookings;
DROP POLICY IF EXISTS "Anyone can confirm booking by token" ON public.bookings;

-- Create a secure function to get booking by token
CREATE OR REPLACE FUNCTION public.get_booking_by_token(_token uuid)
RETURNS TABLE (
  id uuid,
  name text,
  email text,
  phone text,
  street text,
  city text,
  zip text,
  service_type text,
  frequency text,
  preferred_date text,
  preferred_time text,
  scheduled_date text,
  scheduled_time text,
  confirmed_at timestamptz,
  status text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, name, email, phone, street, city, zip, service_type, frequency,
         preferred_date, preferred_time, scheduled_date, scheduled_time, confirmed_at, status
  FROM public.bookings
  WHERE confirmation_token = _token
  LIMIT 1;
$$;

-- Create a secure function to confirm booking by token
CREATE OR REPLACE FUNCTION public.confirm_booking_by_token(_token uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.bookings
  SET confirmed_at = now()
  WHERE confirmation_token = _token
    AND confirmed_at IS NULL;
  RETURN FOUND;
END;
$$;
