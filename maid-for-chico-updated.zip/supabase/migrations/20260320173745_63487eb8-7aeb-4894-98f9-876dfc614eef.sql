
-- Add confirmation tracking to bookings
ALTER TABLE public.bookings 
  ADD COLUMN IF NOT EXISTS confirmation_token uuid DEFAULT gen_random_uuid(),
  ADD COLUMN IF NOT EXISTS confirmed_at timestamp with time zone DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS scheduled_date text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS scheduled_time text DEFAULT NULL;

-- Allow anonymous users to read bookings by confirmation token (for the confirm page)
CREATE POLICY "Anyone can view booking by confirmation token"
  ON public.bookings
  FOR SELECT
  TO anon
  USING (confirmation_token IS NOT NULL);

-- Allow anonymous users to update confirmed_at by confirmation token
CREATE POLICY "Anyone can confirm booking by token"
  ON public.bookings
  FOR UPDATE
  TO anon
  USING (confirmation_token IS NOT NULL)
  WITH CHECK (confirmation_token IS NOT NULL);
