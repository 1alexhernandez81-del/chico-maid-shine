
ALTER TABLE public.bookings ADD COLUMN line_items jsonb DEFAULT '[]'::jsonb;
ALTER TABLE public.bookings ADD COLUMN total_price numeric(10,2) DEFAULT NULL;
ALTER TABLE public.bookings ADD COLUMN invoice_url text DEFAULT NULL;

-- Storage bucket for invoices/receipts
INSERT INTO storage.buckets (id, name, public) VALUES ('invoices', 'invoices', false);

-- Admin can upload invoices
CREATE POLICY "Admins can upload invoices" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'invoices' AND public.has_role(auth.uid(), 'admin'::app_role));

-- Admin can view invoices
CREATE POLICY "Admins can view invoices" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'invoices' AND public.has_role(auth.uid(), 'admin'::app_role));

-- Admin can delete invoices
CREATE POLICY "Admins can delete invoices" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'invoices' AND public.has_role(auth.uid(), 'admin'::app_role));

-- Admin can update invoices
CREATE POLICY "Admins can update invoices" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'invoices' AND public.has_role(auth.uid(), 'admin'::app_role));
