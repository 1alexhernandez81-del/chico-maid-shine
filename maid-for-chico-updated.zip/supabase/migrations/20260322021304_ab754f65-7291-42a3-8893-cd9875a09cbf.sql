CREATE OR REPLACE FUNCTION public.get_booked_estimate_times(_date text)
RETURNS text[]
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT COALESCE(array_agg(estimate_time), '{}')
  FROM public.bookings
  WHERE (estimate_date = _date)
    AND estimate_time IS NOT NULL
    AND status NOT IN ('cancelled', 'declined');
$$;