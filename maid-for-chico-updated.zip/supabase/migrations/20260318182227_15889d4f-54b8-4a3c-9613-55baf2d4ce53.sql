-- Fix search_path on update_updated_at function
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Fix the permissive INSERT policy on bookings - restrict to service_role only
DROP POLICY "Service role can insert bookings" ON public.bookings;

-- Allow anonymous inserts but only via service_role (edge function uses service role key)
-- The edge function runs with service_role which bypasses RLS, so no INSERT policy needed for anon
-- We need to allow the edge function to insert, which uses service_role (bypasses RLS)
-- So we can safely remove the permissive policy