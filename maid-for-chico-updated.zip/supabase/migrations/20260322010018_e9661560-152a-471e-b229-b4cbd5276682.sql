
ALTER TABLE public.bookings 
  ADD COLUMN IF NOT EXISTS estimate_date text,
  ADD COLUMN IF NOT EXISTS estimate_time text;

ALTER TABLE public.customer_communications 
  ADD COLUMN IF NOT EXISTS booking_id uuid REFERENCES public.bookings(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS idx_customer_communications_booking_id ON public.customer_communications(booking_id);
