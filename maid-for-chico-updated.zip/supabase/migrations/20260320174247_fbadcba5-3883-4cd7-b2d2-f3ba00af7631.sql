
-- Add invoice_number with auto-increment sequence
CREATE SEQUENCE IF NOT EXISTS public.invoice_number_seq START WITH 1001;

ALTER TABLE public.bookings 
  ADD COLUMN IF NOT EXISTS invoice_number integer DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS photos text[] DEFAULT '{}';

-- Create function to auto-assign invoice number
CREATE OR REPLACE FUNCTION public.assign_invoice_number()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.invoice_number IS NULL AND OLD.invoice_number IS NULL THEN
    NEW.invoice_number := nextval('public.invoice_number_seq');
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger: assign invoice number when line_items are first added
CREATE TRIGGER assign_invoice_number_trigger
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW
  WHEN (NEW.line_items IS NOT NULL AND (OLD.invoice_number IS NULL))
  EXECUTE FUNCTION public.assign_invoice_number();

-- Create job-photos storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('job-photos', 'job-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload job photos
CREATE POLICY "Authenticated users can upload job photos"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'job-photos');

-- Allow authenticated users to view job photos
CREATE POLICY "Anyone can view job photos"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'job-photos');

-- Allow authenticated users to delete job photos
CREATE POLICY "Authenticated users can delete job photos"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'job-photos');
