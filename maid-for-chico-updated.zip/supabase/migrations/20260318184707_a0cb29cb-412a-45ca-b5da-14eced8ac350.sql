
-- Contact logs table for tracking WhatsApp/call button clicks
CREATE TABLE public.contact_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  channel text NOT NULL, -- 'whatsapp', 'phone'
  source_page text DEFAULT '/'
);

-- Enable RLS
ALTER TABLE public.contact_logs ENABLE ROW LEVEL SECURITY;

-- Allow anonymous inserts (customers aren't logged in)
CREATE POLICY "Anyone can insert contact logs"
  ON public.contact_logs FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Only admins can view logs
CREATE POLICY "Admins can view contact logs"
  ON public.contact_logs FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
