-- Create cleaners table
CREATE TABLE public.cleaners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text DEFAULT '',
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.cleaners ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage cleaners" ON public.cleaners
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Allow employees to view cleaners (for assignment display)
CREATE POLICY "Authenticated users can view cleaners" ON public.cleaners
  FOR SELECT TO authenticated
  USING (true);

-- Add assigned_cleaners array to bookings
ALTER TABLE public.bookings ADD COLUMN assigned_cleaners uuid[] DEFAULT '{}';