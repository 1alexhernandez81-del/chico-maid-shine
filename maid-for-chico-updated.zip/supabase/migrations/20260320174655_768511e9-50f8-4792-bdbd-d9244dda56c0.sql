
-- Add cancelled_at and cancellation_fee columns
ALTER TABLE public.bookings 
  ADD COLUMN IF NOT EXISTS cancelled_at timestamptz DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS cancellation_fee numeric DEFAULT NULL;

-- Function to cancel booking by token (with 24-hour fee check)
CREATE OR REPLACE FUNCTION public.cancel_booking_by_token(_token uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _booking record;
  _fee numeric := 0;
  _scheduled timestamp with time zone;
BEGIN
  SELECT * INTO _booking FROM public.bookings
  WHERE confirmation_token = _token AND cancelled_at IS NULL AND status IN ('scheduled', 'approved')
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'reason', 'not_found');
  END IF;

  -- Check if within 24 hours of scheduled date
  _scheduled := (COALESCE(_booking.scheduled_date, _booking.preferred_date) || ' ' || COALESCE(_booking.scheduled_time, '09:00'))::timestamp;
  
  IF _scheduled - now() < interval '24 hours' THEN
    _fee := 50;
  END IF;

  UPDATE public.bookings
  SET cancelled_at = now(),
      cancellation_fee = _fee,
      status = 'cancelled'
  WHERE confirmation_token = _token;

  RETURN jsonb_build_object('success', true, 'fee', _fee, 'name', _booking.name);
END;
$$;

-- Add reminder_sent flag
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS reminder_sent boolean DEFAULT false;
