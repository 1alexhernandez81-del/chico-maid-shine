CREATE OR REPLACE FUNCTION public.approve_quote_by_token(_token uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _booking record;
BEGIN
  SELECT * INTO _booking FROM public.bookings
  WHERE confirmation_token = _token
    AND status IN ('quoted', 'estimate-scheduled', 'pending', 'contacted')
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'reason', 'not_found');
  END IF;

  UPDATE public.bookings
  SET status = 'approved',
      confirmed_at = now()
  WHERE confirmation_token = _token;

  RETURN jsonb_build_object('success', true, 'name', _booking.name, 'service_type', _booking.service_type);
END;
$$;