
ALTER TABLE public.customer_communications 
  ADD COLUMN IF NOT EXISTS thread_id uuid DEFAULT gen_random_uuid(),
  ADD COLUMN IF NOT EXISTS email_message_id text,
  ADD COLUMN IF NOT EXISTS in_reply_to text,
  ADD COLUMN IF NOT EXISTS direction text NOT NULL DEFAULT 'outbound';

CREATE INDEX IF NOT EXISTS idx_comms_thread_id ON public.customer_communications(thread_id);
CREATE INDEX IF NOT EXISTS idx_comms_booking_thread ON public.customer_communications(booking_id, thread_id);
