

# Maid For Chico — Website Rebuild

## Design & Branding
- **Color scheme** matching the current site: dark charcoal/navy header & hero overlay, red/coral accent text for the logo and headings, light blue bubble decorative elements, white content backgrounds
- Clean, professional layout with the "Maid For Chico" branding and bubble logo motif
- Responsive design for mobile and desktop

## Pages & Sections

### 1. Home Page (Single-page scrolling layout)
- **Navigation bar** — Logo on the left, links on the right: Home, Services, Schedule an Appointment
- **Hero section** — Full-width background image of a clean living room with dark overlay, centered "Maid For Chico" logo text, and tagline about superior quality services at competitive rates
- **Services Areas & Hours section** — White background with light blue bubble decorations, details about:
  - Commercial cleaning (bathrooms, kitchens, break rooms, offices, vacuuming, mopping)
  - Residential cleaning with flat-rate pricing (weekly, bi-weekly, every 3 weeks, monthly)
  - Construction/renovation cleanup
  - Special one-time cleaning projects
- **Why Choose Us section** — Highlights: customer satisfaction focus, quality results, stress-free experience, budget-friendly
- **Footer** — Contact info, service area (Chico), and basic business details

### 2. Service Request Intake Form (Schedule an Appointment page)
A detailed form collecting:
- **Contact info**: Name, email, phone number
- **Address**: Street, city, zip code
- **Service type**: Residential, commercial, construction cleanup, one-time cleaning
- **Home/building details**: Approximate square footage, number of bedrooms/bathrooms
- **Cleaning frequency**: One-time, weekly, bi-weekly, every 3 weeks, monthly
- **Preferred date & time**
- **Special requests / notes** (free text)
- Form validation with clear error messages
- Success confirmation message on submission

> **Note**: The form will work as a front-end only demo initially. If your mom wants to receive submissions via email or save them to a database, we can add that as a next step with Supabase.

